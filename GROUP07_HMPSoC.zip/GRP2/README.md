# Group 7 GRP Phase 2

Open the CS701.qpf Quartus project and compile it. Program the DE1-SOC. Open Eclipse and build the grp_phase_2 project and run that as Nios Hardware on the DE1-SOC.
